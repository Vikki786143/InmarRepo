using System;

namespace Encoder
{
    public class EncoderProcessor
    {
        public string Encode(string message)
        {
            //Implement your code here!
            throw new NotImplementedException();
        }
    }
}