﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace InMar.Models
{
    public class OfferService
    {
        public OfferService()
        {
            AddProducts();

        }

        private List<Product> inventory { get; set; }

        private void AddProducts()
        {
            Product p = new Product();
            p.ProductName = "P1";
            p.Price = 100;
            p.Description = "P1 desc";
            inventory.Add(p);
        }

        public IEnumerable<Product> GetAllProducts()
        {
            return inventory.ToList();
        }
    }
}