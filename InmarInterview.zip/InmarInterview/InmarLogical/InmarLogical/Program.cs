﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InmarLogical
{
    class Program
    {
        static void Main(string[] args)
        {
            string strActual = Console.ReadLine();
            int Len = strActual.Length - 1;

            string strRev = "";

            while(Len>-1)
            {
                strRev = strRev + strActual[Len];
                Len--;
            }
            Console.WriteLine(strRev);
            Console.ReadLine();
        }
    }
}
