﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoopLogical
{
    class Program
    {
        static void Main(string[] args)
        {
                       
           for (int i = 1; i <= 100; i++)
           {

                if (i / 3 > 0 && i > 2)
                {
                    Console.WriteLine(i + ": fizz");

                    if (i / 5 > 0 && i > 4)
                    {
                        Console.WriteLine(i + " :fizzbuzz");                        
                    }
                }
                if (i / 5 > 0 && i > 4)
                {
                    Console.WriteLine(i + " :buzz");                    
                }
            
           }


            Console.ReadLine();
        }
    }
}
